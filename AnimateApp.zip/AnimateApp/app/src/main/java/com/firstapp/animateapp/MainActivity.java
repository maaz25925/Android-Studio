package com.firstapp.animateapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private TextView helloWorldTextView;
    private Button alphaBtn, rotateBtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        helloWorldTextView = findViewById(R.id.textView2);
        alphaBtn = findViewById(R.id.button);
        rotateBtn = findViewById(R.id.button2);
        Animation alphaAnimation = AnimationUtils.loadAnimation(this, R.anim.alpha);
        alphaBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                helloWorldTextView.startAnimation(alphaAnimation);
            }
        });
        Animation rotateAnimation = AnimationUtils.loadAnimation(this, R.anim.rotate);
        rotateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                helloWorldTextView.startAnimation(rotateAnimation);
            }
        });
    }
}